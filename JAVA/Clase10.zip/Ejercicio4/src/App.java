/*
Titulo: Ejercicio 2 - Constructor y metodos
Autor: Jhoantan Torres
Enunciado:
    Crear una clase llamada Producto con los atributos nombre, precio y stock.
    La clase debe tener un constructor, un metodo para mostrar informacion 
    y un metodo par calcular el valor total de inventario
*/

public class App {
    public static void main(String[] args) throws Exception {
        
    }
}
